 im=imread('photpress16.jpg'); 
 imagesc(im); 
 colormap(gray)
 A=double(im);
%[U,S,V]=svd(A);
r=rank(A);
figure(2)
plot(r,'b');
s=svds(A,r);
total=sum(s);
indice_val=zeros(1,length(s));
for k=1:r
    indice_val(k)=s(k)/total;
end
%figure(2)
%plot(r,'b');
b=(321*617)/(0.5*(1+321+617));
round(b);
%Matriz A10
k1=10;
[Ui,Si,Vi]=svds(A,k1);
Adiez=Ui*Si*Vi';
rango=rank(Adiez);
s1=svds(Adiez,rango);
total=sum(s1);
indice_val1=zeros(1,length(s1));
error_k1=zeros(1,length(s1));
ganancia_k1=0;
for k1=1:rango
    indice_val1(k1)=s(k1)/total;
end
indice_val1(k1);
 error_k1=(norm(A-Adiez)/norm(A));
 ganancia_k1=100*k1*(1+321+617)/(321*617);
%Matriz A20
k2=20;
[Ui,Si,Vi]=svds(A,k2);
Aveinte=Ui*Si*Vi';
rango2=rank(Aveinte);
s2=svds(Aveinte,rango2);
total=sum(s2);
indice_val2=zeros(1,length(s2));
error_k2=zeros(1,length(s2));
ganancia_k2=0;
for k2=1:rango2
    indice_val2(k2)=(s(k2)/total)';
end
 error_k2=(norm(A-Aveinte)/norm(A))
 ganancia_k2=100*k2*(1+321+617)/(321*617)
%Matriz A30
k3=30;
[Ui,Si,Vi]=svds(A,k3);
Atreinta=Ui*Si*Vi';
rango3=rank(Atreinta);
s3=svds(Aveinte,rango3);
total=sum(s3);
indice_val3=zeros(1,length(s3));
error_k3=zeros(1,length(s3));
ganancia_k3=0;
for k3=1:rango3
    indice_val3(k3)=s(k3)/total;
end
 error_k3=(norm(A-Atreinta)/norm(A))
 ganancia_k3=100*k3*(1+321+617)/(321*617)
%imagen A10
imdiez=uint8(im);
imagesc(imdiez);colormap(gray)

%imagen A20
imveinte=uint8(Aveinte);
imagesc(imdiez);
colormap(gray)
%imagen A30
imtreinta=uint8(Atreinta);
imagesc(imtreinta);
colormap(gray)
indice_val_total=[indice_val1 indice_val2 indice_val3];
error_relativo=[error_k1 error_k2 error_k3];
subplot(2,2,1);
imagesc(im); colormap(gray)
title('Imagen Original');
subplot(2,2,2);
imagesc(imdiez); colormap(gray)
title('Aproximaci�n de rango 10');
subplot(2,2,3);
imagesc(imveinte); colormap(gray)
title('Aproximaci�n de rango 20');
subplot(2,2,4);
imagesc(imtreinta); colormap(gray)
title('Aproximaci�n de rango 30');
