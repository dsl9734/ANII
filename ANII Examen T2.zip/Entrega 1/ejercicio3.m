% % EJERCICIO 2
% A = [11 -6 4 -2;
%      4 1 0 0;
%      -9 9 -6 5;
%      -6 6 -6 7];
% resA = eig(A)';
% [lambda, x, iter, precision] = potencia(A);
% 
% % Apartado 3
% B = A-lambda * (x) * x';
% resB = eig(B)';
% [lambda2, x2, iter2] = potencia(B);
% 
% hold on;
% semilogy(precision, 'g*');
% k = 1:25;
% tasa = (abs(lambda2/lambda)).^k;
% semilogy(k, tasa, 'r*');

% EJERCICIO 3
% a=30
a = -30;
A = [a 2 3 13;
     5 11 10 8;
     9 7 6 12;
     4 14 15 1];
[lambda1, x, iter, pres] = potencia(A);
B = A-lambda1 * (x) * x';

% % a=-30
% a = -30;
% A = [a 2 3 13;
%      5 11 10 8;
%      9 7 6 12;
%      4 14 15 1];
% [lambda1, x, iter, pres] = potencia(A);
% B = A-lambda1 * (x) * x';

% Respuestas
lambda1
iter
vec_x = x'
residuo = norm(A * x - lambda1 * x)
lambda2 = potencia(B)
valor_abs = abs(lambda2/lambda1)

vec_res = pres(22:32)

