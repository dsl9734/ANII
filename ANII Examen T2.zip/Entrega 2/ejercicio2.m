im = imread('photpress16.jpg');
A = double(im);

% APARTADO 1
dim_A = size(A);

% APARTADO 2
% 2.1
% b
r = rank(A); % rango de A
% a
s = svds(A, r); % valores singulares
figure(1);
plot(s);
% c
total = sum(s);
indice_val = zeros(1, length(s));
for k = 1 : r
    indice_val(k) = s(k)/total;
end
figure(2);
plot(indice_val);
primeras15 = indice_val(1:15);

% 2.2
k = 10;
[u, s, v] = svds(A, k);
A10 = u * s * v';

k = 20;
[u, s, v] = svds(A, k);
A20 = u * s * v';

k = 30;
[u, s, v] = svds(A, k);
A30 = u * s * v';

% 2.3
im10 = uint8(A10);
im20 = uint8(A20);
im30 = uint8(A30);

figure(3)
subplot (2,2,1);
imagesc(im); colormap(gray);
title('Imagen Original');

subplot (2,2,2);
imagesc(im10); colormap(gray);
title('Aproximaci�n de Rango 10');

subplot (2,2,3);
imagesc(im20); colormap(gray);
title('Aproximaci�n de Rango 20');

subplot (2,2,4);
imagesc(im30); colormap(gray);
title('Aproximaci�n de Rango 30');

% APARTADO 3
% Calculo indice_val
% k = 10
r = rank(A10); 
s = svds(A10, r);
total = sum(s);
indice_val_A10 = zeros(1, length(s));
for k = 1 : r
    indice_val_A10(k) = s(k)/total;
end
% k = 20
r = rank(A20); 
s = svds(A20, r);
total = sum(s);
indice_val_A20 = zeros(1, length(s));
for k = 1 : r
    indice_val_A20(k) = s(k)/total;
end
% k = 30
r = rank(A30); 
s = svds(A30, r);
total = sum(s);
indice_val_A30 = zeros(1, length(s));
for k = 1 : r
    indice_val_A30(k) = s(k)/total;
end

% Calculo Error_relativo_k
Error_relativo_10 = norm(A - A10) / norm(A);
Error_relativo_20 = norm(A - A20) / norm(A);
Error_relativo_30 = norm(A - A30) / norm(A);

% Calculo Ganancia_k
[n, m] = size(A);
Ganancia_10 = 100 * 10 * (1 + n + m)/(n * m);
Ganancia_20 = 100 * 20 * (1 + n + m)/(n * m);
Ganancia_30 = 100 * 30 * (1 + n + m)/(n * m);

% Graficos
figure(4);
hold on
y = [0 : 0.01 : indice_val_A10(end)];
plot(10, y, 'bo');

y = [0 : 0.01 : indice_val_A20(end)];
plot(20, y, 'bo');

y = [0 : 0.01 : indice_val_A30(end)];
plot(30, y, 'bo');

plot(indice_val_A10, 'r');
plot(indice_val_A20, 'r');
plot(indice_val_A30, 'r');
hold off
